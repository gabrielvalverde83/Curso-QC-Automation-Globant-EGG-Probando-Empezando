package starter.actions.navigation;

import net.serenitybdd.annotations.DefaultUrl;
import net.serenitybdd.core.pages.PageObject;

@DefaultUrl("https://duckduckgo.com/")
public class DuckDuckGoHomePage extends PageObject {}
